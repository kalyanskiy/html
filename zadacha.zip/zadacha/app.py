from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def index():
    books = dict()
    f_in = open('in.txt', 'r')
    for line in f_in:
        s = line.split()
        reader = s[1]
        n_books = int(s[2])
        if reader in books:
            books[reader] += n_books
        else:
            books[reader] = n_books
    f_in.close()
    sorted_books = sorted(books.items())
    return render_template('index.html', books=sorted_books)


if __name__ == '__main__':
    app.run()
